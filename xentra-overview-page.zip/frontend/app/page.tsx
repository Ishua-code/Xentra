"use client";

import { useMemo, useState } from "react";
import {
  Activity,
  ArrowDownRight,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  CircleHelp,
  Download,
  FileText,
  Filter,
  GitBranch,
  LayoutDashboard,
  LogOut,
  Menu,
  Network,
  Plus,
  Search,
  Settings,
  Shield,
  ShieldAlert,
  UserRound,
  Users,
  X,
  Zap,
} from "lucide-react";
import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useAuth } from "@/lib/auth";

// ---------------------------------------------------------------------------
// Placeholder data. This will be replaced by real calls to
// /api/v1/findings, /api/v1/identities, /api/v1/tickets and /api/v1/correlate
// in a later pass -- for now this ports the mock UI's look and interactions.
// ---------------------------------------------------------------------------

const findings = [
  { cve: "CVE-2021-44228", host: "192.168.1.10", owner: "admin_john", epss: "0.972", identity: 92, severity: "Critical", description: "Remote code execution in Log4j allows unauthenticated attackers to execute arbitrary code on affected servers." },
  { cve: "CVE-2017-0144", host: "192.168.1.24", owner: "svc_backup", epss: "0.914", identity: 86, severity: "Critical", description: "SMBv1 remote code execution vulnerability with known ransomware exploitation." },
  { cve: "CVE-2020-1472", host: "192.168.1.6", owner: "admin_john", epss: "0.742", identity: 79, severity: "High", description: "Zerologon elevation of privilege in Netlogon allows an attacker to impersonate a domain controller." },
  { cve: "CVE-2018-7600", host: "192.168.1.31", owner: "sara_finance", epss: "0.681", identity: 64, severity: "High", description: "Drupalgeddon remote code execution affecting the public web tier." },
  { cve: "CVE-2021-34527", host: "192.168.1.18", owner: "svc_print", epss: "0.574", identity: 58, severity: "High", description: "PrintNightmare allows remote code execution through the Windows Print Spooler." },
  { cve: "CVE-2019-0708", host: "192.168.1.44", owner: "mike_ops", epss: "0.392", identity: 42, severity: "Medium", description: "BlueKeep remote desktop services vulnerability." },
];

const trend = Array.from({ length: 30 }, (_, i) => ({
  day: i + 1,
  score: Math.round(82 - i * 0.34 + Math.sin(i / 2) * 2),
}));

const alerts = [
  "Critical finding crossed EPSS threshold",
  "Scan completed on production-east",
  "Jira ticket XENTRA-241 created",
  "MFA policy drift detected in Finance",
  "Finding CVE-2019-0708 resolved",
  "New identity added to privileged group",
];

const assets = [
  { host: "dc-prod-01", criticality: "Critical", team: "Infrastructure", findings: 12 },
  { host: "payments-api-03", criticality: "Critical", team: "Payments", findings: 8 },
  { host: "finance-laptop-44", criticality: "High", team: "Finance IT", findings: 5 },
  { host: "legacy-web-02", criticality: "Medium", team: "Platform", findings: 3 },
  { host: "backup-node-07", criticality: "High", team: "Infrastructure", findings: 7 },
];

const navItems = [
  { label: "Overview", icon: LayoutDashboard },
  { label: "Vulnerabilities", icon: ShieldAlert },
  { label: "Identities", icon: Users },
  { label: "Attack Paths", icon: Network },
  { label: "Assets", icon: GitBranch },
  { label: "Reports", icon: FileText },
];

const identities = [
  { name: "admin_john", risk: 96 },
  { name: "svc_backup", risk: 84 },
  { name: "sara_finance", risk: 61 },
];

function severityClass(s: string) {
  return `severity-${s.toLowerCase()}`;
}

// ---------------------------------------------------------------------------
// Small shared visual pieces
// ---------------------------------------------------------------------------

function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <div className="logo-mark">
        <Shield className="size-4" />
      </div>
      <div>
        <p className="text-sm font-bold tracking-[.22em] text-white">XENTRA</p>
        <p className="text-[8px] tracking-[.18em] text-slate-500">THREAT FUSION</p>
      </div>
    </div>
  );
}

function Sparkline({
  color = "#60a5fa",
  points = [4, 7, 5, 9, 8, 12, 10],
}: {
  color?: string;
  points?: number[];
}) {
  return (
    <svg viewBox="0 0 80 24" className="sparkline" aria-hidden="true">
      <polyline
        points={points.map((p, i) => `${i * 13},${22 - p * 1.5}`).join(" ")}
        fill="none"
        stroke={color}
        strokeWidth="1.8"
      />
    </svg>
  );
}

function RiskRing() {
  return (
    <div className="risk-ring">
      <div>
        <strong>72</strong>
        <span>/100</span>
        <small>MODERATE RISK</small>
      </div>
    </div>
  );
}

function AttackPath() {
  const nodes: [string, string, string, string][] = [
    ["node-user", "weak_user", "10%", "48%"],
    ["node-user", "svc_backup", "28%", "18%"],
    ["node-pivot", "admin_pivot", "39%", "45%"],
    ["node-server", "payments-api", "57%", "70%"],
    ["node-domain", "DOMAIN_ADMIN", "87%", "34%"],
  ];
  return (
    <div className="attack-graph attack-graph-large">
      <svg className="attack-lines" viewBox="0 0 760 300" preserveAspectRatio="none">
        <path d="M80 170 C180 60 220 80 310 145 S430 240 520 130 S630 70 700 115" />
        <path d="M310 145 C350 80 410 70 470 100" />
      </svg>
      {nodes.map(([kind, label, left, top]) => (
        <div key={label}>
          <div className={`graph-node ${kind}`} style={{ left, top }}>
            {kind === "node-pivot" ? <Zap /> : kind === "node-domain" ? <Shield /> : <UserRound />}
          </div>
          <span className="graph-label" style={{ left, top: `calc(${top} + 12%)` }}>
            {label}
          </span>
        </div>
      ))}
    </div>
  );
}

function AppButton({
  children,
  onClick,
  variant = "outline",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "outline" | "default";
}) {
  return (
    <Button
      onClick={onClick}
      variant={variant}
      size="sm"
      className={
        variant === "default"
          ? "bg-blue-600 text-white hover:bg-blue-500"
          : "border-slate-700 bg-transparent text-slate-300 hover:bg-slate-800"
      }
    >
      {children}
    </Button>
  );
}

// ---------------------------------------------------------------------------
// Sidebar + top bar (wired to real auth)
// ---------------------------------------------------------------------------

function Sidebar({
  active,
  setActive,
  sidebarOpen,
  setSidebarOpen,
}: {
  active: string;
  setActive: (label: string) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}) {
  const { username, logout } = useAuth();
  const initials = username ? username.slice(0, 2).toUpperCase() : "??";

  return (
    <aside className={`xentra-sidebar ${sidebarOpen ? "is-open" : ""}`}>
      <div className="px-5 py-5">
        <div className="flex items-center justify-between">
          <Logo />
          <button className="lg:hidden" onClick={() => setSidebarOpen(false)} aria-label="Close navigation">
            <X />
          </button>
        </div>
      </div>
      <div className="px-3 pt-2">
        <p className="eyebrow px-3 pb-2">Workspace</p>
        {navItems.map(({ label, icon: Icon }) => (
          <button
            key={label}
            onClick={() => {
              setActive(label);
              setSidebarOpen(false);
            }}
            className={`nav-item ${active === label ? "active" : ""}`}
          >
            <Icon />
            {label}
            {label === "Assets" && <span className="ml-auto text-[9px] text-slate-600">248</span>}
          </button>
        ))}
        <p className="eyebrow px-3 pb-2 pt-6">System</p>
        <button onClick={() => setActive("Settings")} className={`nav-item ${active === "Settings" ? "active" : ""}`}>
          <Settings />
          Settings
        </button>
        <button className="nav-item">
          <CircleHelp />
          Help center
        </button>
      </div>
      <div className="sidebar-user">
        <Avatar className="size-8">
          <AvatarFallback className="bg-blue-500/20 text-xs text-blue-300">{initials}</AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="truncate text-xs font-semibold text-white">{username ?? "Unknown user"}</p>
          <p className="truncate text-[10px] text-slate-500">Security Analyst</p>
        </div>
        <button className="icon-btn ml-auto" onClick={logout} aria-label="Log out" title="Log out">
          <LogOut className="size-4" />
        </button>
      </div>
    </aside>
  );
}

function TopBar({
  active,
  alertsOpen,
  setAlertsOpen,
  setSidebarOpen,
}: {
  active: string;
  alertsOpen: boolean;
  setAlertsOpen: (open: boolean) => void;
  setSidebarOpen: (open: boolean) => void;
}) {
  return (
    <header className="topbar">
      <button className="mr-1 lg:hidden" onClick={() => setSidebarOpen(true)} aria-label="Open navigation">
        <Menu />
      </button>
      <div className="min-w-0">
        <p className="eyebrow">Security operations / {active}</p>
        <h1>{active === "Overview" ? "Overview dashboard" : active}</h1>
      </div>
      <div className="ml-auto flex items-center gap-2">
        <div className="search-wrap hidden md:flex">
          <Search />
          <Input placeholder="Search workspace" />
        </div>
        <div className="relative">
          <button className="icon-btn" onClick={() => setAlertsOpen(!alertsOpen)} aria-label="Notifications">
            <Bell />
            <span className="notification-dot">4</span>
          </button>
          {alertsOpen && (
            <div className="alerts-dropdown">
              <p className="mb-3 text-xs font-semibold text-white">
                Notifications <span className="float-right text-[10px] text-blue-400">Mark all read</span>
              </p>
              {alerts.map((a, i) => (
                <div className="alert-item" key={a}>
                  <span className={`incident-dot severity-${i < 2 ? "critical" : "medium"}`} />
                  <div>
                    <p>{a}</p>
                    <small>{i + 2} min ago</small>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <AppButton variant="default">
          <Zap data-icon="inline-start" />
          Run new scan
        </AppButton>
      </div>
    </header>
  );
}

// ---------------------------------------------------------------------------
// Page-level sections
// ---------------------------------------------------------------------------

function PageIntro({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div className="mb-5">
      <p className="eyebrow text-blue-400">Workspace</p>
      <h2 className="mt-1 text-xl font-semibold text-white">{title}</h2>
      <p className="mt-1 text-sm text-slate-500">{subtitle}</p>
    </div>
  );
}

function AssetTable() {
  return (
    <Card className="dashboard-card">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Asset inventory</CardTitle>
          <AppButton variant="default">
            <Plus data-icon="inline-start" />
            Add asset
          </AppButton>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Host</TableHead>
              <TableHead>Criticality</TableHead>
              <TableHead>Owner team</TableHead>
              <TableHead>Open findings</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {assets.map((a) => (
              <TableRow key={a.host}>
                <TableCell className="font-mono text-xs text-blue-300">{a.host}</TableCell>
                <TableCell>
                  <Badge className={severityClass(a.criticality)}>{a.criticality}</Badge>
                </TableCell>
                <TableCell>{a.team}</TableCell>
                <TableCell>{a.findings}</TableCell>
                <TableCell>
                  <span className="text-emerald-400">● Online</span>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function Reports() {
  return (
    <div className="dashboard-content">
      <PageIntro title="Reports" subtitle="Generate analyst-ready security reports from your workspace data." />
      <div className="report-grid">
        {["Executive risk brief", "Vulnerability register", "Identity exposure report", "Compliance evidence"].map((r) => (
          <Card className="dashboard-card" key={r}>
            <CardContent className="p-5">
              <div className="report-icon">
                <FileText />
              </div>
              <h3 className="mt-4 text-sm font-semibold text-white">{r}</h3>
              <p className="mt-1 text-xs text-slate-500">PDF · Updated today</p>
              <AppButton>
                <Download data-icon="inline-start" />
                Generate report
              </AppButton>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SettingsPage() {
  return (
    <div className="dashboard-content">
      <PageIntro title="Settings" subtitle="Manage workspace connections and notification routing." />
      <Card className="dashboard-card">
        <CardHeader>
          <CardTitle>Integrations</CardTitle>
        </CardHeader>
        <CardContent className="integration-grid">
          {["Slack", "Jira", "ServiceNow", "PagerDuty"].map((x) => (
            <div className="integration-card" key={x}>
              <div className="flex items-center gap-3">
                <div className="integration-logo">{x[0]}</div>
                <div>
                  <p className="text-sm font-semibold text-white">{x}</p>
                  <p className="text-[10px] text-slate-500">Incident routing and alerts</p>
                </div>
              </div>
              <AppButton>Connect</AppButton>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}

function DetailPanel({
  finding,
  onClose,
}: {
  finding: (typeof findings)[number];
  onClose: () => void;
}) {
  return (
    <div className="detail-overlay" onClick={onClose}>
      <aside className="detail-panel" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div>
            <p className="eyebrow text-blue-400">Finding detail</p>
            <h2 className="mt-1 font-mono text-lg text-white">{finding.cve}</h2>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close detail">
            <X />
          </button>
        </div>
        <Badge className={`mt-4 ${severityClass(finding.severity)}`}>{finding.severity} severity</Badge>
        <p className="mt-4 text-sm leading-6 text-slate-300">{finding.description}</p>
        <div className="detail-stats">
          <div>
            <span>CVSS</span>
            <strong>9.8</strong>
          </div>
          <div>
            <span>EPSS</span>
            <strong>{finding.epss}</strong>
          </div>
          <div>
            <span>Identity risk</span>
            <strong>{finding.identity}</strong>
          </div>
        </div>
        <h3 className="detail-heading">Attack path chain</h3>
        <div className="chain">
          <span>weak_user</span>
          <b>-&gt;</b>
          <span>admin_pivot</span>
          <b>-&gt;</b>
          <span>DOMAIN_ADMIN</span>
        </div>
        <h3 className="detail-heading">Remediation</h3>
        <label>
          Assign owner
          <Select defaultValue={finding.owner}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="admin_john">admin_john</SelectItem>
              <SelectItem value="sara_finance">sara_finance</SelectItem>
              <SelectItem value="mike_ops">mike_ops</SelectItem>
            </SelectContent>
          </Select>
        </label>
        <label>
          Due date
          <Input type="date" defaultValue="2026-10-02" />
        </label>
        <label>
          Status
          <Select defaultValue="open">
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="progress">In progress</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
        </label>
        <AppButton variant="default">Save remediation</AppButton>
      </aside>
    </div>
  );
}

function OverviewContent({
  tab,
  setTab,
  query,
  setQuery,
  filterOpen,
  setFilterOpen,
  filtered,
  ticketed,
  createTicket,
  setSelected,
}: {
  tab: string;
  setTab: (t: string) => void;
  query: string;
  setQuery: (q: string) => void;
  filterOpen: boolean;
  setFilterOpen: (o: boolean) => void;
  filtered: typeof findings;
  ticketed: string[];
  createTicket: (cve: string) => void;
  setSelected: (f: (typeof findings)[number] | null) => void;
}) {
  return (
    <div className="dashboard-content">
      <div className="mb-5 flex items-end justify-between">
        <div>
          <p className="eyebrow text-blue-400">Live environment · Production</p>
          <h2 className="mt-1 text-xl font-semibold text-white">Good morning</h2>
        </div>
        <p className="hidden text-[11px] text-slate-500 sm:block">
          Last sync <span className="text-slate-300">2 min ago</span>
        </p>
      </div>

      <div className="workspace-grid">
        <aside className="pulse-rail">
          <Card className="dashboard-card pulse-main">
            <CardContent className="flex flex-col items-center p-4">
              <p className="eyebrow self-start">Risk pulse</p>
              <RiskRing />
              <p className="mt-1 text-center text-[10px] leading-4 text-slate-500">
                Posture is improving
                <br />
                but 3 critical paths remain.
              </p>
            </CardContent>
          </Card>
          {(
            [
              ["Vulnerabilities", "1,284", "+12.5%", "#60a5fa"],
              ["Identities", "8,492", "+4.8%", "#a78bfa"],
              ["Open incidents", "07", "+2", "#fbbf24"],
            ] as const
          ).map(([label, value, delta, color], i) => (
            <div className="pulse-row" key={label}>
              <div>
                <p className="text-[10px] uppercase tracking-wider text-slate-500">{label}</p>
                <strong>{value}</strong>
                <span className={i === 0 ? "text-red-400" : "text-emerald-400"}>
                  {i === 0 ? <ArrowUpRight /> : <ArrowDownRight />}
                  {delta}
                </span>
              </div>
              <Sparkline color={color} points={i === 1 ? [6, 5, 8, 7, 11, 10, 14] : undefined} />
            </div>
          ))}
        </aside>

        <section className="workspace-center">
          <div className="tab-bar">
            {["Findings", "Attack Paths", "Assets", "Trends"].map((t) => (
              <button key={t} onClick={() => setTab(t)} className={tab === t ? "active" : ""}>
                {t}
              </button>
            ))}
            <button className="filter-trigger" onClick={() => setFilterOpen(!filterOpen)} aria-label="Open filters">
              <Filter />
            </button>
          </div>

          {filterOpen && (
            <div className="filter-panel">
              <p className="text-xs font-semibold text-white">Filter findings</p>
              <label>
                <input type="checkbox" defaultChecked /> Critical
              </label>
              <label>
                <input type="checkbox" defaultChecked /> High
              </label>
              <label>
                <input type="checkbox" /> Medium / Low
              </label>
              <div className="filter-fields">
                <Input placeholder="Owner search" />
                <Select defaultValue="all">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All asset criticality</SelectItem>
                    <SelectItem value="critical">Critical only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <p className="text-[10px] text-slate-500">
                <CalendarDays /> Last 30 days
              </p>
            </div>
          )}

          {tab === "Findings" && (
            <Card className="dashboard-card tab-panel overflow-hidden">
              <CardHeader className="border-b border-slate-800/80 pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Prioritized findings</CardTitle>
                    <p className="mt-1 text-[11px] text-slate-500">Click any row to inspect the full attack chain.</p>
                  </div>
                  <div className="search-wrap table-search">
                    <Search />
                    <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Filter findings" />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>CVE ID</TableHead>
                        <TableHead>Host</TableHead>
                        <TableHead>Owner</TableHead>
                        <TableHead>EPSS</TableHead>
                        <TableHead>Identity risk</TableHead>
                        <TableHead>Severity</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((f) => (
                        <TableRow key={f.cve} className="cursor-pointer" onClick={() => setSelected(f)}>
                          <TableCell className="font-mono text-xs text-blue-300">{f.cve}</TableCell>
                          <TableCell className="font-mono text-xs text-slate-400">{f.host}</TableCell>
                          <TableCell className="text-xs">{f.owner}</TableCell>
                          <TableCell className="font-mono text-xs">{f.epss}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <div className="risk-track">
                                <span style={{ width: `${f.identity}%` }} />
                              </div>
                              <span className="text-xs">{f.identity}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge className={severityClass(f.severity)}>{f.severity}</Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          )}

          {tab === "Attack Paths" && (
            <Card className="dashboard-card tab-panel">
              <CardHeader>
                <CardTitle>Privilege escalation graph</CardTitle>
                <p className="text-xs text-slate-500">Highest confidence route · 5 nodes · 3 hops to domain admin</p>
              </CardHeader>
              <CardContent>
                <AttackPath />
              </CardContent>
            </Card>
          )}

          {tab === "Assets" && <AssetTable />}

          {tab === "Trends" && (
            <Card className="dashboard-card tab-panel">
              <CardHeader>
                <CardTitle>Risk score trend</CardTitle>
                <p className="text-xs text-slate-500">30 day unified posture score · lower is better</p>
              </CardHeader>
              <CardContent>
                <div className="h-[380px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trend}>
                      <XAxis dataKey="day" tick={{ fill: "#64748b", fontSize: 10 }} tickLine={false} axisLine={false} />
                      <YAxis domain={[60, 90]} tick={{ fill: "#64748b", fontSize: 10 }} tickLine={false} axisLine={false} />
                      <Tooltip contentStyle={{ background: "#111827", border: "1px solid #263247", fontSize: 11 }} />
                      <Line type="monotone" dataKey="score" stroke="#60a5fa" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}
        </section>

        <aside className="action-panel">
          <Card className="dashboard-card">
            <CardHeader className="pb-2">
              <CardTitle>Needs your attention</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-2">
              {findings.slice(0, 3).map((f) => (
                <div className="attention-item" key={f.cve}>
                  <div className="flex items-center justify-between gap-2">
                    <Badge className={severityClass(f.severity)}>{f.severity}</Badge>
                    <span className="font-mono text-[10px] text-blue-300">{f.cve}</span>
                  </div>
                  <p>{f.description.slice(0, 58)}...</p>
                  <button onClick={() => createTicket(f.cve)} className="ticket-link">
                    {ticketed.includes(f.cve) ? (
                      <>
                        <Check /> Ticket created
                      </>
                    ) : (
                      <>
                        <Plus /> Create ticket
                      </>
                    )}
                  </button>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="dashboard-card">
            <CardHeader className="pb-2">
              <CardTitle>Recent activity</CardTitle>
            </CardHeader>
            <CardContent className="activity-feed">
              {[
                "Ticket XENTRA-241 created",
                "Finding CVE-2019-0708 resolved",
                "Production scan completed",
                "Alex joined Security Engineering",
              ].map((a, i) => (
                <div key={a}>
                  <span className="activity-line" />
                  <Activity />
                  <div>
                    <p>{a}</p>
                    <small>{i * 12 + 4} min ago</small>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="dashboard-card">
            <CardHeader className="pb-2">
              <CardTitle>Top risky identities</CardTitle>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              {identities.map((id) => (
                <div key={id.name}>
                  <div className="flex justify-between text-[11px]">
                    <span>{id.name}</span>
                    <span className="text-slate-500">{id.risk}</span>
                  </div>
                  <div className="mt-1 h-1 rounded bg-slate-800">
                    <div
                      className={`h-full rounded ${id.risk > 80 ? "bg-red-500" : "bg-orange-500"}`}
                      style={{ width: `${id.risk}%` }}
                    />
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </aside>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function Page() {
  const [active, setActive] = useState("Overview");
  const [tab, setTab] = useState("Findings");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<(typeof findings)[number] | null>(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [alertsOpen, setAlertsOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [ticketed, setTicketed] = useState<string[]>([]);

  const filtered = useMemo(
    () => findings.filter((f) => Object.values(f).join(" ").toLowerCase().includes(query.toLowerCase())),
    [query]
  );

  const createTicket = (cve: string) => setTicketed((t) => [...new Set([...t, cve])]);

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-200">
      <Sidebar active={active} setActive={setActive} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />

      <main className="lg:pl-[224px]">
        <TopBar active={active} alertsOpen={alertsOpen} setAlertsOpen={setAlertsOpen} setSidebarOpen={setSidebarOpen} />

        {active === "Overview" ? (
          <OverviewContent
            tab={tab}
            setTab={setTab}
            query={query}
            setQuery={setQuery}
            filterOpen={filterOpen}
            setFilterOpen={setFilterOpen}
            filtered={filtered}
            ticketed={ticketed}
            createTicket={createTicket}
            setSelected={setSelected}
          />
        ) : active === "Assets" ? (
          <div className="dashboard-content">
            <PageIntro title="Asset inventory" subtitle="Hosts, ownership, and exposure across production." />
            <AssetTable />
          </div>
        ) : active === "Reports" ? (
          <Reports />
        ) : active === "Settings" ? (
          <SettingsPage />
        ) : (
          <div className="dashboard-content">
            <PageIntro title={active} subtitle="Workspace view is ready for analyst workflows." />
            <Card className="dashboard-card">
              <CardContent className="p-8 text-sm text-slate-400">
                Select Overview, Assets, Reports, or Settings to explore the live reference interactions.
              </CardContent>
            </Card>
          </div>
        )}
      </main>

      {selected && <DetailPanel finding={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
